# Google-Virtual-Internship---Android-Application-Development-Using-Kotlin--unit-1<img width="960" alt="happy" src="https://user-images.githubusercontent.com/83489094/187024204-6cf5e45b-7171-4496-8d53-b08c26be5f1c.png">

<br>
<p>
Day 1 Google Virtual Internship Android Dev using Kotlin
</p>
<h2>Hello World Unit-1</h2>
